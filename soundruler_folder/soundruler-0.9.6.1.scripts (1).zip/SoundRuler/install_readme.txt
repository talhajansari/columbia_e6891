==================  SOUND RULER ======================

     Contents:

    1- Sound Ruler release types.

    2- System requirements.

    3- Installation and removal - Windows stand alone.

    4- Installation and removal - M-file scripts.

---------------------------------------------------------------------------

    1- Sound Ruler release types:

    MS Windows stand alone (soundruler-0.9.x.x.windows.exe)
	You do not need Matlab to run it.

    OSX (Mac) stand alone (soundruler-0.9.x.x.osx.pkg)
        You do not need Matlab to run it.

    Unix (Linux) stand alone (soundruler-0.9.x.x.linux.tar.gz)
        You do not need Matlab to run it.

    RPM Linux stand alone (soundruler-0.9.x.x.linux.rpm)
        You do not need Matlab to run it.

    M-files script (soundruler-0.9.x.x.scripts.zip)
	Requires Matlab to run.
        It runs on any platform.


   NOTE:
      In comparison with the binary versions, the script version:
         Is slower.
         It allows you to adjust the code to fit your needs.
         It requires Matlab as it runs inside it.


---------------------------------------------------------------------------

     2- System requirements:

     Sound Ruler itself does not demand many resources, but sound
analysis is very processor intensive. The more extensive and detailed 
your analyses are, the more you will benefit from a fast computer.

     Although Sound Ruler runs well in a Pentium 2 at 233 MHz, even an 
upgrade from a Pentium 4 at 1.7 GHz to a Pentium 4 at 2.4 GHz can 
produce pronounced reduction in analysis time.

     Stand alone MSWindows version:

          Pentium 100 (486 not tested yet) 
          32 MB of RAM memory 
          50 MB of free hard disk space 
          Windows 95 or newer

     Stand alone Linux version:

          100 MHz processor 
          32 MB of RAM memory 
          50 MB of free hard disk space
          X windows
          Sox (for playing sounds)

     M-files script versions:
          Matlab version 6.x 
          10 MB of free hard disk space 

---------------------------------------------------------------------------

     3- Installation / Removal - Windows stand alone

     3.1- Can Sound Ruler coexist with Matlab installations?

     Yes, The past issues with path setting should be gone. SoundRuler now 
installs the Matlab libraries in its own directory and does not place any
setting in the general path. 


     Installation:

        Do not install over a previous version. Remove the previous 
version first, or install the new one in another directory.

	1- Download soundruler-0.9.x.x.windows.exe and double-click on it.
        2- Follow the instructions on the screen.

     Removal:

	1- Go to Start-Settings-Control Panel-Add/Remove Programs.
        2- Select SoundRuler from the list of programs.
	If you saved files into the SoundRuler folder, this folder will
not be deleted during the uninstall process.

---------------------------------------------------------------------------
 
     4- Installation / Removal - M-files script 

     Installation:

                       AUTOMATIC SETUP (Windows only)

	1- unzip the SoundRuler files into a folder
	2- open Matlab
	3- enter cd foldername, where foldername is the folder where you
		put the SoundRuler files 
           ex:  cd 'c:\program files\soundruler'
	4- enter setupsruler

	When done, enter sruler at Matlab's prompt to run SoundRuler

                       MANUAL SETUP

	1- unzip the SoundRuler files into a folder
	2- open Matlab
	3- enter cd foldername, where foldername is the folder where you
		put the SoundRuler files 
           ex:  cd 'c:\program files\soundruler'
	4- run soundruler.m

                       What does the auto setup do?

	This is a clean installation.
	All it does is to place a sruler.m file in your matlab/work
folder. The /work folder is in Matlabs path by default.
	Every time you type sruler, it adds the SoundRuler folder to
Matlabs path and runs soundruler.

     Removal:
	1- Back up the files that you might have saved into the folder where
you SoundRuler is installed.
	2- Delete SoundRuler's folder.


----------------------------------------------------------------------------
2007-02-15

