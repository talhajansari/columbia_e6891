<html><title>Sound Ruler - Download</title>
<body bgcolor="#FFFFFF">
<table width="100%" border="0" bgcolor="#000000" cellpadding="0" cellspacing="0">
  <tr>
    <td width="53%"><a href="index.html"><img src="final/sublgogo.gif" width="390" height="65" border="0"></a></td>
    <td width="47%">
      <div align="center"><font color="#FFFFFF"><b><font size="3" face="Arial, Helvetica, sans-serif">Bioac&uacute;stica 
        Brasil</font></b></font></div>
    </td>
  </tr>
</table>
<p><?php require 'http://lists.sourceforge.net/lists/listinfo/soundruler-bioacustica'; ?> </p>
<p><font face="Arial, Helvetica, sans-serif" size="1"><a href="index-br.htm">P&aacute;gina 
  Inicial</a></font></p>
<table width="100%" border="0" bgcolor="#000000">
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<p>&nbsp;</p>
</html>
