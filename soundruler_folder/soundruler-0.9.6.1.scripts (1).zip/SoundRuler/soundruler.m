function soundruler()
%
% soundruler
%
%    Acoustic analysis and graphing of sequences of signals.
%
%    You can use SoundRuler to generate costummized plots of oscilograms,
% power spectra or spectrograms. You can also guide the program in 
% measuring the signals and storing the results.
%
%    SoundRuler measures various temporal and spectral characteristics of 
% the signals contained in a .wav file and outputs the results in 
% semicolon delimited .txt files. You specify the settings used by the 
% algoritms that take the measurements, the program shows you the 
% results and you decide on storing the values, skipping the signal or
% adjusting the settings and measuring again. You can also take 
% measurements manually with the mouse.
%
%    The source files have to be in Windows PCM (.wav) format, at any 
% sampling rate and bit resolution, and they can be mono or stereo.
%
%    To install, cd to the folder where the m-files are and enter setupsruler
% at Matlab's prompt. Find more info in SetupSRuler.txt.

%% title
%1 A package for acoustic analysis in research and teaching

%% authors
%2 Marcos Gridi-Papp <mgpapp@users.sourceforge.net>

%% developer help
%%3 Explain how it works

%% status (alpha, beta)
%4 beta

%% functions (files) it calls
%5 sman.m store.m gv.m settingsman.m 

%% subfunctions (same file)
%%6 getano, getayes

%0 ---------------------- end of header --------------------------------

tic % starts timer

% Stops if vibrotoolbox is in the path
if exist('vibrotoolbox.m')==2
   errordlg({'SoundRuler cannot run in script mode (binary is fine) while';...
           'VibroToolbox is running. Please close VibroToolbox and try again.';'';...
           'If Vibrotoolbox is not running, for some reason the path to it is';...
           'active in Matlab (check with the command path). Please remove it from';...
           'the path (rmpath) or restart Matlab.';'';...
            'If you added the path to Vibrotoolbox to your Matlab path intentionaly,';...
            'please consider instead running setupvibrotb.m (in the root of the program).'},...
            'VibroToolbox is in the path','modal')
   uiwait
   cd('..')
   return 
end 

% Stops if soundruler already open
if ~(isempty(findobj('tag','hSRulerFig'))), return, end

% call OS compatibility code to define path
compat('soundruler-path');

sets = 0;
% get settings if fresh open
if strcmp(gv('vProgOS'),'win') == 1  % windows
    lastsetfile = [gv('vHomePath') 'sruler.lst'];
else
    lastsetfile = [gv('vHomePath') '.sruler.lst'];
end
% load last settings file used
if exist(lastsetfile) > 0, sets = sman('loadAll','start');, end

%  start logging
logger('start');
% Need drwnow to update event list, or main window starts to load before textpad
% is loaded and the handles get messed up
drawnow 

% initialize object counting
pv('vCurrWhat',1);
pv('vCurrFile',1);
pv('vCurrSection',1);
pv('vCurrCall',1);
pv('vCurrPulse',1);

% set main window size type
switch gv('screenMode')
case 1 % auto
    screenResol = get(0,'ScreenSize');
    if screenResol(3) >= 1024, pv('vScreenSize',1024);,else, pv('vScreenSize',800); end
case 2 % force small
    pv('vScreenSize',800);
case 3 % force large
    pv('vScreenSize',1024);
end

% call OS compatibility code to open main window
%compat('soundruler-opengui',gv('vScreenSize'));
srulergui;

% display info on settings
if sets == 0
   set(gv('hlStatusR'),'string',['Settings - default'])
   logger('settsFile',['Loaded the default settings.'])
else
   set(gv('hlStatusR'),'string',['Settings - ' gv('vSettPath') gv('vSettFile')])
   logger('settsFile',['Loaded settings file ' gv('vSettPath') gv('vSettFile') '.'])
end

% set the colormap for spectrograms
setgeneral('updateCMap');
%switch gv('cmapMode')
%case 1 % gray (b on w)
%   set(gv('hSRulerFig'),'colormap',flipud(gray(100)));
%   pv('cmapFile',[]);
%case 2 % gray inv (w on b) -> gray
%   colormap(gv('hAxes3'),'gray');
%   pv('cmapFile',[]);
%case 3 % color -> hsv
%   colormap(gv('hAxes3'),'jet');
%   pv('cmapFile',[]);
%case 4 % custom
%   cmap = cmapload(gv('cmapFile'));
%   if isempty(cmap)
%      colormap('jet');      
%   else
%      set(gcf,'colormap',cmap.cmap);
%   end
%end

% initialize results matrix
store(1,1,1);
