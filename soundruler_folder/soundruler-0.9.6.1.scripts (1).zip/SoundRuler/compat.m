function varargout = compat(varargin)
%
%    compat
%
%    It contains parts of code that are specific to release type or platform.

%% title
%1 Platform-specific compatibility code

%% author
%2 2006-02-09 Marcos Gridi-Papp <mgpapp@users.sourceforge.net>

%% dev
%3    compat.m is a copy of compatwin or compatun. The right file is copied 
%3       over compat.m by codecompat.m. This method is used instead of
%3       conditional clauses (if then end) because the mcc compiler tracks
%3       every command in a file to include in the compilation. It ignores
%3       if statements and tries to compile platform-specific code that
%3       generates errors.
%3    compatun.m contains code that is specific to unix machines but common
%3       to Linux and OSX. A similar secondary compatibility system separates
%3       the code that is specific to each OS. One of compatunixlin or
%3       compatunixosx are copied over compatunix.m. 

%% status (alpha, beta)
%4 beta

%% functions (files) it calls
%5 sman.m gv.m

%% subfunctions (same file)
%%6 getano, getayes

%0 ---------------------- end of header --------------------------------

% The listed calls are:
% soundruler-path
% soundruler-opengui
% cca-uigetdir
% progmenuadd-opencrosscorr

% show help if no option specified
if nargin == 0, helpdev('compat','user');return,end

switch varargin{1} % look up the function to run
case 'soundruler-path'  % -----------------------------------------------------
    
   % scripts = scp    binary = bin
   progType = 'scp'; %soundrulerspec(1);

   switch computer
       case 'PCWIN'
           progOS = 'win';
           libpath = getenv('LD_LIBRARY_PATH');
       case 'GLNX86'
           progOS = 'lin';
           libpath = getenv('LD_LIBRARY_PATH');
       case 'MAC'
           progOS = 'osx';
           libpath = getenv('DYLD_LIBRARY_PATH');
   end
   if strcmp(progOS,'win') == 1  % windows
       progPath = [pwd filesep];
       homePath = progPath;
   else % osx or linux
       if strcmp(progType,'scp') == 1 % script
          progPath = [pwd filesep]; 
       else  % binary
          progPath = libpath(1:length(libpath)-10);
       end
       homePath = [getenv('HOME') filesep];
   end
   srulertype = [progOS progType];  % delete these lines with settingsman
   srulerpath = progPath;
   homepath = homePath;

   % the order of the following 3 blocks can not be changed.
   % the path to the code subdirectories need to be defined to give access
   % to sman. Then the memory structure can be initialized. After that
   % it is possible to store the path variables and return to the general 
   % part of the main function.
   
   % add path to code parts
   if strcmp(progType,'scp')==1
      addpath([progPath]);
      pathStr = getpathstr(progPath);    % subfunction at the bottom
      for i=1:size(pathStr,1)
         addpath(pathStr{i});
      end
   end

   % initialize the memory structure
   sman('initSetts','start');
   pv('vProgType',progType);
   pv('vProgOS',progOS);   
   defaultset('defAll','start');  

   % set paths
   soundpath = [progPath 'sounds' filesep];
   filterpath = [progPath 'filters' filesep];
   settpath = [progPath 'settings' filesep];
   resultpath = [progPath 'results' filesep];
   figpath = [progPath 'figures' filesep];
   pv('vProgPath',progPath);
   pv('vHomePath',homePath);
   pv('vSoundPath',[progPath 'sounds' filesep]);
   pv('vFilterPath',[progPath 'filters' filesep]);
   pv('vSettPath',[progPath 'settings' filesep]);
   pv('vResultPath',[progPath 'results' filesep]);
   pv('vFigPath',[progPath 'figures' filesep]);
   pv('vCMapPath',[progPath 'colormaps' filesep]);
    
case 'closefig-rmpath'  % -----------------------------------------------------
   if strcmp(gv('vProgType'),'scp')==1;
      progPath = gv('vProgPath');
      pathStr = getpathstr;    % subfunction at the bottom
      for i=1:size(pathStr,1)
         rmpath(pathStr{i});
      end
      rmpath([progPath]);
   end
    
case 'cca-uigetdir'     % -----------------------------------------------------
   varargout{1} = uigetdir(gv('vSoundPath'), 'Choose an input directory...');   

case 'convsetfiles-uigetdir'   % ----------------------------------------------
   varargout{1} = uigetdir(gv('vSettPath'), 'Choose an input directory...');
    
case 'expgraphsmenu-plotedit'  % -------------------------------------------
 hmEdit = varargin{2};
 if strcmp(gv('vProgOS'),'win') & strcmp(gv('vProgType'),'scp')
   uimenu(...
   'Parent',hmEdit,...
   'Callback','editmenufcn(gcbf,''EditCopyOptions'')',...
   'Label','Copy &Options',...
   'Tag','cbCopyOptions');

   uimenu(...
   'Parent',hmEdit,...
   'Callback','plotedit(''on'')',...
   'Label','&Edit Plots',...
   'Tag','cbEditPlots');
 end
 
otherwise              
    % if not found, repass to unix OS specific function (linux or osx)
   compatunix(varargin);
end

 % -----------------------------------------------------
% Function to supply the path strings to add and start and to remove at exit
function out = getpathstr(varargin)
if nargin > 0, progPath = varargin{1};, else, progPath = gv('vProgPath');, end
out = {
      [progPath 'bin' filesep 'analysis' filesep];...
      [progPath 'bin' filesep 'analysis' filesep 'calibampl' filesep];...
      [progPath 'bin' filesep 'analysis' filesep 'cca' filesep];...
      [progPath 'bin' filesep 'analysis' filesep 'section' filesep];...
      [progPath 'bin' filesep 'analysis' filesep 'localization' filesep];...
      [progPath 'bin' filesep 'analysis' filesep 'call' filesep];...
      [progPath 'bin' filesep 'audio' filesep];...
      [progPath 'bin' filesep 'audio' filesep 'vocoder' filesep];...
      [progPath 'bin' filesep 'dev' filesep];...
      [progPath 'bin' filesep 'filters' filesep];...
      [progPath 'bin' filesep 'filters' filesep 'bandpass' filesep];...
      [progPath 'bin' filesep 'filters' filesep 'tuningcurve' filesep];...
      [progPath 'bin' filesep 'graphs' filesep];...
      [progPath 'bin' filesep 'graphs' filesep 'amplspect' filesep];...
      [progPath 'bin' filesep 'graphs' filesep 'modulspect' filesep];...
      [progPath 'bin' filesep 'graphs' filesep 'taperspect' filesep];...
      [progPath 'bin' filesep 'graphs' filesep 'export' filesep];...
      [progPath 'bin' filesep 'graphs' filesep 'spectrogram' filesep];...
      [progPath 'bin' filesep 'help' filesep];...
      [progPath 'bin' filesep 'help' filesep 'about' filesep];...
      [progPath 'bin' filesep 'help' filesep 'registration' filesep];...
      [progPath 'bin' filesep 'main' filesep];...
      [progPath 'bin' filesep 'playback' filesep];...
      [progPath 'bin' filesep 'print' filesep];...
      [progPath 'bin' filesep 'saving' filesep];...
      [progPath 'bin' filesep 'soundmath' filesep];...
      [progPath 'bin' filesep 'tools' filesep];...
      [progPath 'bin' filesep 'tools' filesep 'mouse' filesep];...
      [progPath 'bin' filesep 'tools' filesep 'textpad' filesep]
  };
%   [progPath 'bin' filesep 'graphs' filesep 'autocorr' filesep];...
%   [progPath 'bin' filesep 'graphs' filesep 'cepstrum' filesep];...
%   [progPath 'bin' filesep 'synthesis' filesep];...
